package regionserver;

import java.sql.*;

import org.apache.curator.framework.CuratorFramework;

public class RegionServerToClientUtils {
    public static void createTable(CuratorFramework client, String cmd, Statement statement) {

    }
}