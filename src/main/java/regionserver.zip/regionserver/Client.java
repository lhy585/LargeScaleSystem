package regionserver;

import java.io.*;
import java.net.*;
import java.util.ArrayList;
import java.util.concurrent.*;

import net.sf.jsqlparser.schema.Server;
import org.apache.curator.framework.CuratorFramework;
import zookeeper.TableInform;
import zookeeper.ZooKeeperManager;

/**
 * RegionServer 的 Client，负责与 Master 进行通信，包括注册 RegionServer 和处理 Master 的指令。
 */
public class Client implements Runnable {
    private static final String MASTER_HOST = "127.0.0.1"; // Master 的主机地址
    private static final int MASTER_PORT = 1001;         // Master 的端口号

    private Socket masterSocket;
    private BufferedReader masterReader;
    private BufferedWriter masterWriter;

    private volatile boolean running = true;
    private String regionServerId; // 自动生成的 RegionServer ID

    private ZooKeeperManager zooKeeperManager;
    private ArrayList<TableInform> tables;

    /**
     * 构造函数
     *
     * @param zooKeeperManager ZooKeeper 管理器实例
     * @param tables 表信息列表
     */
    public Client(ZooKeeperManager zooKeeperManager, ArrayList<TableInform> tables) {
        this.zooKeeperManager = zooKeeperManager;
        this.tables = tables;
    }

    @Override
    public void run() {
        try {
            // 连接到 Master
            connectToMaster();

            // 注册 RegionServer 到 Master
            registerRegionServer();

            // 启动监听来自 Master 的请求
            listenForMasterRequests();

        } catch (IOException e) {
            System.err.println("[RegionServerClient] Error during initialization: " + e.getMessage());
        } finally {
            stop();
        }
    }

    /**
     * 连接到 Master
     *
     * @throws IOException 如果连接失败
     */
    private void connectToMaster() throws IOException {
        masterSocket = new Socket(MASTER_HOST, MASTER_PORT);
        masterWriter = new BufferedWriter(new OutputStreamWriter(masterSocket.getOutputStream(), "UTF-8"));
        masterReader = new BufferedReader(new InputStreamReader(masterSocket.getInputStream(), "UTF-8"));
        System.out.println("[RegionServerClient] Connected to Master at " + MASTER_HOST + ":" + MASTER_PORT);
    }

    /**
     * 注册 RegionServer 到 Master
     *
     * @throws IOException 如果注册失败
     */
    private void registerRegionServer() throws IOException {
        // 自动生成 RegionServer ID（如 RS_1, RS_2, ...）
        this.regionServerId = "RS_1";   // 假设有一个生成唯一ID的方法

        // 获取本地的 IP 地址和端口
        String localHostAddress = getLocalHostAddress();
        int clientPort = getClientPort();

        String registrationInfo = "REGISTER_REGION_SERVER " + regionServerId + " " + localHostAddress + ":" + clientPort;
        masterWriter.write(registrationInfo);
        masterWriter.newLine();
        masterWriter.flush();

        String response = masterReader.readLine();
        if ("REGISTERED".equals(response)) {
            System.out.println("[RegionServerClient] Successfully registered with Master as " + regionServerId);
        } else {
            throw new IOException("Failed to register with Master: " + response);
        }
    }

    /**
     * 获取本地的 IP 地址
     *
     * @return 本地 IP 地址字符串
     */
    private String getLocalHostAddress() {
        try {
            return java.net.InetAddress.getLocalHost().getHostAddress();
        } catch (Exception e) {
            return "UNKNOWN";
        }
    }

    /**
     * 获取本地的 Client 端口
     *
     * @return 本地 Client 端口号
     */
    private int getClientPort() {
        // 这里假设 RegionServer 的 Client 监听端口是固定的，或者需要动态分配
        // 为简化示例，这里返回一个固定值，实际项目中应根据需求调整
        return 6000; // 假设 Client 监听在 6000 端口
    }

    /**
     * 启动监听来自 Master 的请求线程
     */
    private void listenForMasterRequests() {
        Thread masterListenerThread = new Thread(() -> {
            try {
                String request;
                while (running && (request = masterReader.readLine()) != null) {
                    System.out.println("[RegionServerClient] Received request from Master: " + request);

                    if (request.contains("REGISTER")) continue;

                    // 解析请求类型和参数
                    String[] parts = request.split(" ", 2);
                    if (parts.length < 1) {
                        System.err.println("[RegionServerClient] Invalid request format: " + request);
                        continue;
                    }

                    String command = parts[0].toUpperCase();
                    String params = parts.length > 1 ? parts[1] : "";

                    switch (command) {
                        case "INSERT":
                            handleInsert(params);
                            break;
                        case "DELETE":
                            handleDelete(params);
                            break;
                        case "UPDATE":
                            handleUpdate(params);
                            break;
                        case "SELECT":
                            handleSelect(params);
                            break;
                        case "TRUNCATE":
                            handleTruncate(params);
                            break;
                        case "CREATE_TABLE":
                            handleCreateTable(params);
                            break;
                        case "DROP_TABLE":
                            handleDropTable(params);
                            break;
                        case "ALTER_TABLE":
                            handleAlterTable(params);
                            break;
                        default:
                            System.err.println("[RegionServerClient] Unknown command from Master: " + command);
                            sendResponseToMaster("ERROR Unknown command");
                            break;
                    }
                }
            } catch (IOException e) {
                if (running) {
                    System.err.println("[RegionServerClient] Error while listening for Master requests: " + e.getMessage());
                }
            } finally {
                stop();
            }
        });
        masterListenerThread.setDaemon(true); // 设置为守护线程，主程序退出时自动结束
        masterListenerThread.start();
        System.out.println("[RegionServerClient] Started listener thread for Master requests.");
    }

    /**
     * 处理来自 Master 的 INSERT 请求。
     *
     * @param params 请求参数，通常包含 SQL 语句
     */
    private void handleInsert(String params) {
        try {
            // 假设 params 包含完整的 INSERT SQL 语句
            boolean success = ServerClient.executeCmd(params);
            if (success) {
                sendResponseToMaster("SUCCESS INSERT");
            } else {
                sendResponseToMaster("FAILURE INSERT");
            }
        } catch (Exception e) {
            System.err.println("[RegionServerClient] Error handling INSERT: " + e.getMessage());
            sendResponseToMaster("FAILURE INSERT");
        }
    }

    /**
     * 处理来自 Master 的 DELETE 请求。
     *
     * @param params 请求参数，通常包含 SQL 语句
     */
    private void handleDelete(String params) {
        try {
            // 假设 params 包含完整的 DELETE SQL 语句
            boolean success = ServerClient.executeCmd(params);
            if (success) {
                sendResponseToMaster("SUCCESS DELETE");
            } else {
                sendResponseToMaster("FAILURE DELETE");
            }
        } catch (Exception e) {
            System.err.println("[RegionServerClient] Error handling DELETE: " + e.getMessage());
            sendResponseToMaster("FAILURE DELETE");
        }
    }

    /**
     * 处理来自 Master 的 UPDATE 请求。
     *
     * @param params 请求参数，通常包含 SQL 语句
     */
    private void handleUpdate(String params) {
        try {
            // 假设 params 包含完整的 UPDATE SQL 语句
            boolean success = ServerClient.executeCmd(params);
            if (success) {
                sendResponseToMaster("SUCCESS UPDATE");
            } else {
                sendResponseToMaster("FAILURE UPDATE");
            }
        } catch (Exception e) {
            System.err.println("[RegionServerClient] Error handling UPDATE: " + e.getMessage());
            sendResponseToMaster("FAILURE UPDATE");
        }
    }

    /**
     * 处理来自 Master 的 SELECT 请求。
     *
     * @param params 请求参数，通常包含 SQL 语句
     */
    private void handleSelect(String params) {
        try {
            // 假设 params 包含完整的 SELECT SQL 语句
            String result = ServerClient.selectTable(params); // 需要根据实际情况调整
            if (result != null) {
                sendResponseToMaster("SUCCESS SELECT " + result);
            } else {
                sendResponseToMaster("FAILURE SELECT");
            }
        } catch (Exception e) {
            System.err.println("[RegionServerClient] Error handling SELECT: " + e.getMessage());
            sendResponseToMaster("FAILURE SELECT");
        }
    }

    /**
     * 处理来自 Master 的 TRUNCATE 请求。
     *
     * @param params 请求参数，通常包含表名
     */
    private void handleTruncate(String params) {
        try {
            // 假设 params 包含表名
            String[] parts = params.split(" ");
            if (parts.length < 1) {
                sendResponseToMaster("FAILURE TRUNCATE Invalid parameters");
                return;
            }
            String tableName = parts[0];
            String sql = "TRUNCATE TABLE " + tableName;
            // 假设 RegionManager 有 truncateTable 方法
//            boolean success = ServerClient.truncateTable(tableName, sql);
            boolean success = true;
            if (success) {
                sendResponseToMaster("SUCCESS TRUNCATE");
            } else {
                sendResponseToMaster("FAILURE TRUNCATE");
            }
        } catch (Exception e) {
            System.err.println("[RegionServerClient] Error handling TRUNCATE: " + e.getMessage());
            sendResponseToMaster("FAILURE TRUNCATE");
        }
    }

    /**
     * 处理来自 Master 的 CREATE_TABLE 请求。
     *
     * @param params 请求参数，通常包含表名和 SQL 语句
     */
    private void handleCreateTable(String params) {
        try {
            // 假设 params 包含表名和完整的 CREATE TABLE SQL 语句
            String[] parts = params.split(" ", 2);
            if (parts.length < 2) {
                sendResponseToMaster("FAILURE CREATE_TABLE Invalid parameters");
                return;
            }
            String tableName = parts[0];
            String createSQL = parts[1];
            // 这里需要将创建表的请求转发给 RegionServer 的数据库执行逻辑
            boolean success = executeCreateTable(tableName, createSQL);
            if (success) {
                sendResponseToMaster("SUCCESS CREATE_TABLE");
            } else {
                sendResponseToMaster("FAILURE CREATE_TABLE");
            }
        } catch (Exception e) {
            System.err.println("[RegionServerClient] Error handling CREATE_TABLE: " + e.getMessage());
            sendResponseToMaster("FAILURE CREATE_TABLE");
        }
    }

    /**
     * 处理来自 Master 的 DROP_TABLE 请求。
     *
     * @param params 请求参数，通常包含表名
     */
    private void handleDropTable(String params) {
        try {
            // 假设 params 包含表名
            String tableName = params.trim();
            String sql = "DROP TABLE IF EXISTS " + tableName;
            boolean success = ServerClient.dropTable(tableName);
            if (success) {
                sendResponseToMaster("SUCCESS DROP_TABLE");
            } else {
                sendResponseToMaster("FAILURE DROP_TABLE");
            }
        } catch (Exception e) {
            System.err.println("[RegionServerClient] Error handling DROP_TABLE: " + e.getMessage());
            sendResponseToMaster("FAILURE DROP_TABLE");
        }
    }

    /**
     * 处理来自 Master 的 ALTER_TABLE 请求。
     *
     * @param params 请求参数，通常包含表名和 SQL 语句
     */
    private void handleAlterTable(String params) {
        try {
            // 假设 params 包含表名和完整的 ALTER TABLE SQL 语句
            String[] parts = params.split(" ", 2);
            if (parts.length < 2) {
                sendResponseToMaster("FAILURE ALTER_TABLE Invalid parameters");
                return;
            }
            String tableName = parts[0];
            String alterSQL = parts[1];
//            boolean success = ServerClient.alterTable(tableName, alterSQL);
            boolean success = true;
            if (success) {
                sendResponseToMaster("SUCCESS ALTER_TABLE");
            } else {
                sendResponseToMaster("FAILURE ALTER_TABLE");
            }
        } catch (Exception e) {
            System.err.println("[RegionServerClient] Error handling ALTER_TABLE: " + e.getMessage());
            sendResponseToMaster("FAILURE ALTER_TABLE");
        }
    }

    /**
     * 执行创建表的 SQL 语句
     *
     * @param tableName 表名
     * @param createSQL 创建表的 SQL 语句
     * @return 是否成功
     */
    private boolean executeCreateTable(String tableName, String createSQL) {
        return true;
//        if (statement != null) { // 需要将 statement 传递给 RegionServerClient 或通过其他方式获取
//            try {
//                statement.execute(createSQL);
//                System.out.println("[RegionServerClient] Table " + tableName + " created successfully.");
//                return true;
//            } catch (SQLException e) {
//                System.err.println("[RegionServerClient] Failed to create table " + tableName + ": " + e.getMessage());
//                return false;
//            }
//        } else {
//            System.err.println("[RegionServerClient] Statement is not initialized.");
//            return false;
//        }
    }

    /**
     * 向 Master 发送响应。
     *
     * @param response 响应消息
     */
    private void sendResponseToMaster(String response) {
        try {
            masterWriter.write(response);
            masterWriter.newLine();
            masterWriter.flush();
        } catch (IOException e) {
            System.err.println("[RegionServerClient] Failed to send response to Master: " + e.getMessage());
        }
    }

    /**
     * 停止 RegionServerClient。
     */
    public void stop() {
        running = false;
        try {
            if (masterWriter != null) {
                masterWriter.close();
            }
            if (masterReader != null) {
                masterReader.close();
            }
            if (masterSocket != null && !masterSocket.isClosed()) {
                masterSocket.close();
            }
        } catch (IOException e) {
            System.err.println("[RegionServerClient] Error while stopping RegionServerClient: " + e.getMessage());
        }
        System.out.println("[RegionServerClient] Stopped.");
    }

    // 注意：为了使 executeCreateTable 方法能够访问 statement，需要将 statement 传递给 RegionServerClient
    // 或者通过其他方式获取。这可能需要重构代码，将 statement 作为参数传递或在类中持有引用。
    // 由于 RegionServer 和 RegionServerClient 在同一个进程中，可以考虑共享某些资源。
}