package regionserver;
import java.sql.*;

public class SqlQuery {
    private static int connectSQL()
    {
        return 0;
    }
    public static void main(String[] args)
    {
        System.out.println("hello world");
    }
}
