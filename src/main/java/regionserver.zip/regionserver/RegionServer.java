package regionserver;

import java.io.*;
import java.net.*;
import java.sql.*;
import java.util.*;
import java.util.concurrent.*;

import javax.net.ServerSocketFactory;

import org.apache.zookeeper.KeeperException;
import zookeeper.TableInform;
import zookeeper.ZooKeeperManager;

/**
 * RegionServer 主类，负责启动服务器并处理来自 Client 和 Master 的通信。
 */
public class RegionServer implements Runnable {
    public static String ip;
    public static String port;
    public static String mysqlUser;
    public static String mysqlPwd;

    public static Connection connection = null;
    public static Statement statement = null;

    public static ServerSocket serverSocket = null;
    public static ThreadPoolExecutor threadPoolExecutor = null;

    public static Boolean quitSignal = false;
    public static List<TableInform> tables; // 使用自定义的 TableInfo 类

    public static String serverPath;
    public static String serverValue;

    static {
        ip = getIPAddress();
        mysqlUser = "root";
        mysqlPwd = "040517cc";
        port = "5001";
        tables = new ArrayList<>();
    }

    @Override
    public void run() {
        ZooKeeperManager zooKeeperManager = initRegionServer();

        // 启动与 Master 的通信线程
        Client masterClient = new Client(zooKeeperManager, (ArrayList<TableInform>) tables);
        Thread masterThread = new Thread(masterClient);
        masterThread.setDaemon(true); // 设置为守护线程，主程序退出时自动结束
        masterThread.start();
        System.out.println("Started Master communication thread.");

        // 主动连接 Master 并注册 RegionServer
        try (Socket masterSocket = new Socket("127.0.0.1", 5000); // 连接到 Master 的端口
             BufferedReader in = new BufferedReader(new InputStreamReader(masterSocket.getInputStream()));
             PrintWriter out = new PrintWriter(masterSocket.getOutputStream(), true)) {

            System.out.println("[RegionServer] Connected to Master!");

            // 发送注册消息
            out.println("REGISTER_REGION_SERVER " + ip + ":" + port);
            out.flush();

            // 等待 Master 的响应
            String response = in.readLine();
            System.out.println("[RegionServer] Master response: " + response);

            if (!"REGISTERED".equals(response)) {
                throw new IOException("Failed to register with Master: " + response);
            }

            // 持续接收 Master 的指令
            String command;
            while ((command = in.readLine()) != null && !quitSignal) {
                System.out.println("[RegionServer] Received command from Master: " + command);
                // 处理 Master 的指令（如 CREATE_TABLE, INSERT_DATA 等）
                handleMasterCommand(command);
            }
        } catch (IOException e) {
            System.err.println("[RegionServer] Failed to connect to Master or communicate: " + e.getMessage());
        } finally {
            stop();
        }
    }

    /**
     * 处理来自 Master 的指令
     *
     * @param command Master 发送的指令
     */
    private void handleMasterCommand(String command) {
        // 根据指令类型进行处理
        // 示例：假设 Master 发送 "CREATE_TABLE tableName createTableSQL"
        if (command.startsWith("CREATE_TABLE")) {
            String[] parts = command.split(" ", 3);
            if (parts.length == 3) {
                String tableName = parts[1];
                String createSQL = parts[2];
                try {
                    executeCreateTable(tableName, createSQL);
                    // 通知 Master 创建成功
                    // 这里需要实现与 Master 的响应机制，可能需要通过 RegionServerClient 反馈
                } catch (SQLException e) {
                    System.err.println("[RegionServer] Failed to create table " + tableName + ": " + e.getMessage());
                    // 通知 Master 创建失败
                }
            } else {
                System.err.println("[RegionServer] Invalid CREATE_TABLE command format: " + command);
            }
        } else {
            System.err.println("[RegionServer] Unknown command from Master: " + command);
        }
    }

    /**
     * 执行创建表的 SQL 语句
     *
     * @param tableName 表名
     * @param createSQL 创建表的 SQL 语句
     * @throws SQLException 如果执行失败
     */
    private void executeCreateTable(String tableName, String createSQL) throws SQLException {
        if (connection != null && statement != null) {
            // 假设需要指定数据库，例如 "USE lss;"
            try {
                statement.execute("USE lss;");
            } catch (SQLException e) {
                // 如果数据库不存在，可能需要先创建
                statement.execute("CREATE DATABASE IF NOT EXISTS lss;");
                statement.execute("USE lss;");
            }
            statement.execute(createSQL);
            System.out.println("[RegionServer] Table " + tableName + " created successfully.");
        } else {
            throw new SQLException("Database connection or statement is not initialized.");
        }
    }

    /**
     * 初始化 RegionServer，包括数据库连接和 ZooKeeper 节点
     *
     * @return ZooKeeperManager 实例
     */
    public static ZooKeeperManager initRegionServer() {
        ZooKeeperManager zooKeeperManager = new ZooKeeperManager();
        System.out.println("Initializing RegionServer...");

        // 动态选择可用端口
        port = String.valueOf(1001);
        System.out.println("Selected port: " + port);

        // 确保每次初始化都创建新的连接和 statement
        try {
            if (connection != null) {
                connection.close();
            }
            connection = JdbcUtils.getConnection(mysqlUser, mysqlPwd);
            if (connection != null) {
                statement = connection.createStatement();
            } else {
                throw new SQLException("Failed to establish database connection.");
            }
        } catch (SQLException e) {
            System.out.println("Failed to initialize database connection: " + e.getMessage());
            e.printStackTrace();
            // 根据需求决定是否抛出异常或继续
        }

        System.out.println("Clearing MySQL data...");
        clearMysqlData();

        System.out.println("Creating ZooKeeper node...");
        createZooKeeperNode(zooKeeperManager);

        System.out.println("Creating socket and thread pool...");
        createSocketAndThreadPool();

        return zooKeeperManager;
    }

    /**
     * 清理 MySQL 数据，删除并重新创建数据库
     */
    public static void clearMysqlData() {
        if (connection != null && statement != null) {
            try {
                // 删除已有数据库
                String deleteDB = "DROP DATABASE IF EXISTS lss;";
                statement.execute(deleteDB);
                // 重新创建数据库
                String createDB = "CREATE DATABASE IF NOT EXISTS lss;";
                statement.execute(createDB);

                // 使用新创建的数据库
                String useDB = "USE lss;";
                statement.execute(useDB);
            } catch (Exception e) {
                System.out.println("Error clearing MySQL data: " + e.getMessage());
                e.printStackTrace();
            }
        } else {
            System.out.println("Connection or statement is not initialized. Cannot clear MySQL data.");
        }
    }

    /**
     * 创建 ZooKeeper 节点
     *
     * @param zooKeeperManager ZooKeeper 管理器实例
     */
    public static void createZooKeeperNode(ZooKeeperManager zooKeeperManager) {
        try {
            System.out.println("Calling RegionServer.createZooKeeperNode");

            serverPath = "/lss/region_server/" + ip; // 修改路径以包含IP
            serverValue = ip + "," + port + "," + mysqlUser + "," + mysqlPwd + ",3306,0";

            // 检查节点是否存在
            if (zooKeeperManager.nodeExists(serverPath)) {
                System.out.println("ZooKeeper node already exists at path: " + serverPath + ". Continuing to use it.");

                // 获取现有节点的数据并更新tables列表
                String existingValue = zooKeeperManager.getData(serverPath);
                if (existingValue != null && !existingValue.isEmpty()) {
                    // 解析现有节点数据并更新tables
                    // 假设数据格式为 "ip,port,mysqlUser,mysqlPwd,port2master,port2regionserver"
                    // 需要根据实际数据格式调整解析逻辑
                    // 这里假设tables信息存储在其他路径，如 /lss/region_server/{ip}/table/
                    updateTablesFromZooKeeper(zooKeeperManager, ip);
                } else {
                    System.out.println("Warning: Existing ZooKeeper node has no data.");
                }
            } else {
                // 节点不存在，创建新节点
                // 注意：这里需要根据实际的 ZooKeeperManager 实现来添加 RegionServer
                // 假设 ZooKeeperManager 有一个方法 addRegionServer
                zooKeeperManager.addRegionServer(ip, port, tables, mysqlPwd, mysqlUser, "2182", "3306");
                System.out.println("ZooKeeper node created successfully at path: " + serverPath);
            }
        } catch (KeeperException.NodeExistsException e) {
            System.out.println("ZooKeeper node already exists at path: " + serverPath + ". Continuing to use it.");

            // 获取现有节点的数据并更新tables列表
            try {
                String existingValue = zooKeeperManager.getData(serverPath);
                if (existingValue != null && !existingValue.isEmpty()) {
                    // 解析现有节点数据并更新tables
                    updateTablesFromZooKeeper(zooKeeperManager, ip);
                } else {
                    System.out.println("Warning: Existing ZooKeeper node has no data.");
                }
            } catch (Exception ex) {
                System.out.println("Error retrieving data from existing ZooKeeper node: " + ex.getMessage());
                ex.printStackTrace();
            }
        } catch (Exception e) {
            System.out.println("Error creating ZooKeeper node: " + e.getMessage());
            e.printStackTrace();
        }
    }

    /**
     * 根据现有的 ZooKeeper 节点数据更新 tables 列表
     *
     * @param zooKeeperManager ZooKeeper 管理器实例
     * @param ip               RegionServer 的 IP 地址
     * @throws Exception 如果解析或更新失败
     */
    private static void updateTablesFromZooKeeper(ZooKeeperManager zooKeeperManager, String ip) throws Exception {
        // 假设 tables 存储在 /lss/region_server/{ip}/table/{tableName}/
        String tablesPath = "/lss/region_server/" + ip + "/table";
        List<String> tableNames = zooKeeperManager.getChildren(tablesPath);

        for (String tableName : tableNames) {
            // 这里可以根据需要进一步解析每个表的信息
            // 例如，读取 /lss/region_server/{ip}/table/{tableName}/payload 获取表的详细信息
            tables.add(new TableInform(tableName, 0));
            System.out.println("Added table from ZooKeeper: " + tableName);
        }
    }

    /**
     * 创建 ServerSocket 和线程池
     */
    public static void createSocketAndThreadPool() {
        try {
            ServerSocketFactory serverSocketFactory = ServerSocketFactory.getDefault();
            serverSocket = serverSocketFactory.createServerSocket(Integer.valueOf(port));
            System.out.println("Server socket created on port: " + port);
        } catch (IOException e) {
            System.out.println("Error creating server socket: " + e.getMessage());
            e.printStackTrace();
        }

        threadPoolExecutor = new ThreadPoolExecutor(
                60,
                100,
                20,
                TimeUnit.SECONDS,
                new ArrayBlockingQueue<>(20),
                Executors.defaultThreadFactory(),
                new ThreadPoolExecutor.AbortPolicy()
        );
    }

    /**
     * 获取本机 IP 地址
     *
     * @return IP 地址字符串
     */
    public static String getIPAddress() {
        String res = null;
        try {
            InetAddress addr = InetAddress.getLocalHost();
            System.out.println("Local HostAddress: " + addr.getHostAddress());
            res = addr.getHostAddress();
            String hostname = addr.getHostName();
            System.out.println("Local host name: " + hostname);
        } catch (UnknownHostException e) {
            System.out.println("Error getting IP address: " + e.getMessage());
        }
        return res;
    }

    /**
     * 获取可用的 TCP 端口
     *
     * @return 可用的端口号
     */
    public static int getAvailableTcpPort() {
        for (int i = 1000; i <= 65535; i++) {
            try (ServerSocket serverSocket = new ServerSocket(i)) {
                serverSocket.close();
                return i;
            } catch (IOException e) {
                continue;
            }
        }
        return 0;
    }

    /**
     * 停止 RegionServer
     */
    public static void stop() {
        quitSignal = true;
        try {
            if (serverSocket != null && !serverSocket.isClosed()) {
                serverSocket.close();
            }
        } catch (IOException e) {
            System.out.println("Error closing server socket: " + e.getMessage());
        }
        if (threadPoolExecutor != null && !threadPoolExecutor.isShutdown()) {
            threadPoolExecutor.shutdown();
            try {
                if (!threadPoolExecutor.awaitTermination(5, TimeUnit.SECONDS)) {
                    threadPoolExecutor.shutdownNow();
                }
            } catch (InterruptedException e) {
                threadPoolExecutor.shutdownNow();
            }
        }
        // 关闭数据库连接
        try {
            if (statement != null) {
                statement.close();
            }
            if (connection != null && !connection.isClosed()) {
                connection.close();
            }
        } catch (SQLException e) {
            System.out.println("Error closing database connection: " + e.getMessage());
        }
        System.out.println("RegionServer stopped.");
    }

    /**
     * 处理来自 Client 的 SQL 请求
     *
     * @param clientSocket 客户端的 Socket 连接
     */
    private static void handleClientRequest(Socket clientSocket) {
        try (
                BufferedReader in = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));
                PrintWriter out = new PrintWriter(clientSocket.getOutputStream(), true)
        ) {
            String sql;
            while ((sql = in.readLine()) != null && !quitSignal) {
                System.out.println("[RegionServer] Received SQL from Client: " + sql);
                // 解析并执行 SQL
                String response = executeSQL(sql);
                out.println(response);
            }
        } catch (IOException e) {
            if (!quitSignal) {
                System.err.println("[RegionServer] Error handling client request: " + e.getMessage());
            }
        } finally {
            try {
                clientSocket.close();
            } catch (IOException e) {
                System.err.println("[RegionServer] Error closing client socket: " + e.getMessage());
            }
        }
    }

    /**
     * 执行 SQL 请求
     *
     * @param sql SQL 语句
     * @return 响应字符串
     */
    private static String executeSQL(String sql) {
        // 这里需要根据 SQL 类型执行相应的操作
        // 示例：简单解析并执行
        try {
            if (sql.trim().toUpperCase().startsWith("SELECT")) {
                // 执行 SELECT 查询
                ResultSet rs = statement.executeQuery(sql);
                // 将结果集转换为字符串（简化示例）
                StringBuilder result = new StringBuilder("SUCCESS: ");
                ResultSetMetaData metaData = rs.getMetaData();
                int columnCount = metaData.getColumnCount();

                // 添加列名
                for (int i = 1; i <= columnCount; i++) {
                    result.append(metaData.getColumnName(i));
                    if (i < columnCount) result.append(", ");
                }
                result.append("\n");

                // 添加数据行
                while (rs.next()) {
                    for (int i = 1; i <= columnCount; i++) {
                        result.append(rs.getString(i));
                        if (i < columnCount) result.append(", ");
                    }
                    result.append("\n");
                }
                rs.close();
                return result.toString();
            } else {
                // 执行 INSERT, UPDATE, DELETE 等
                int affectedRows = statement.executeUpdate(sql);
                return "SUCCESS: " + affectedRows + " rows affected.";
            }
        } catch (SQLException e) {
            System.err.println("[RegionServer] SQL execution error: " + e.getMessage());
            return "ERROR: " + e.getMessage();
        }
    }

    /**
     * 主方法，启动 RegionServer
     *
     * @param args 命令行参数
     */
    public static void main(String[] args) {
        RegionServer server = new RegionServer();
        Thread serverThread = new Thread(server);
        serverThread.start();

        // 等待服务器线程结束（实际上，服务器应持续运行）
        try {
            serverThread.join();
        } catch (InterruptedException e) {
            System.err.println("[RegionServer] Server thread interrupted.");
        } finally {
            stop();
        }
    }
}